package com.example.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
       private EditText textConta;
        private EditText textDisplay;
        private Button btn0, btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9;
        private Button btnCE, btnIgual, btnSomar, btnSubtrair, btnMultiplicar, btnDividir;
        private double valor1, valor2, resultado;
        private String operacao = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       textDisplay = findViewById(R.id.txtDisplay);
        textConta = findViewById(R.id.textConta);

        btn0 = findViewById(R.id.btn0);
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);
        btn5 = findViewById(R.id.btn5);
        btn6 = findViewById(R.id.btn6);
        btn7 = findViewById(R.id.btn7);
        btn8 = findViewById(R.id.btn8);
        btn9 = findViewById(R.id.btn9);

        btnCE = findViewById(R.id.btnCE);
        btnIgual = findViewById(R.id.btnIgual);
        btnSomar = findViewById(R.id.btnSomar);
        btnSubtrair = findViewById(R.id.btnSubtrair);
        btnMultiplicar = findViewById(R.id.btnMultiplicar);
        btnDividir = findViewById(R.id.btnDividir);

        btn0.setOnClickListener(clickBotaoNumerico);
        btn1.setOnClickListener(clickBotaoNumerico);
        btn2.setOnClickListener(clickBotaoNumerico);
        btn3.setOnClickListener(clickBotaoNumerico);
        btn4.setOnClickListener(clickBotaoNumerico);
        btn5.setOnClickListener(clickBotaoNumerico);
        btn6.setOnClickListener(clickBotaoNumerico);
        btn7.setOnClickListener(clickBotaoNumerico);
        btn8.setOnClickListener(clickBotaoNumerico);
        btn9.setOnClickListener(clickBotaoNumerico);

        btnSomar.setOnClickListener(clickBotaoOperacao);
        btnSubtrair.setOnClickListener(clickBotaoOperacao);
        btnMultiplicar.setOnClickListener(clickBotaoOperacao);
        btnDividir.setOnClickListener(clickBotaoOperacao);

        btnIgual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                valor2 = Double.parseDouble(textDisplay.getText().toString());
                switch (operacao){
                    case "+": resultado = valor1 + valor2;break;
                    case "-": resultado = valor1 - valor2;break;
                    case "*": resultado = valor1 * valor2;break;
                    case "/": resultado = valor1 / valor2;break;
                }
                textDisplay.setText(Double.toString(resultado));

                textConta.setText( valor1 +" "+ operacao +" "+ valor2 + " =");
            }

        });

        btnCE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                operacao = "";
                textDisplay.setText("");

            }
        });






    }

    View.OnClickListener clickBotaoNumerico = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Button botaoPressionado = (Button)v;
            textDisplay.setText(textDisplay.getText().toString() + botaoPressionado.getText());
        }
    };

    View.OnClickListener clickBotaoOperacao = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            Button botaoPressionado = (Button)v;
            operacao = botaoPressionado.getText().toString();
            valor1 = Double.parseDouble(textDisplay.getText().toString());
            Toast.makeText(MainActivity.this, operacao, Toast.LENGTH_SHORT).show();

            textDisplay.setText("");
        }
    };




}